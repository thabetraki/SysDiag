# SysDiag v4 — Génération automatique du .exe (sans avoir besoin de Windows)

Ce dossier contient tout ce qu'il faut pour que **GitHub compile le `.exe` à ta place**, sur un serveur Windows gratuit dans le cloud. Tu n'as besoin d'aucune machine Windows, ni d'installer Python, ni PyInstaller.

## Contenu du dossier

```
sysdiag-release/
├── .github/workflows/build.yml   ← Le "robot" qui compile automatiquement
├── SysDiag_v4.py                 ← Le programme
├── sysdiag.spec                  ← Configuration PyInstaller
├── sysdiag.manifest              ← Élévation admin automatique (UAC)
├── version_info.txt              ← Métadonnées du fichier .exe
├── build_exe.bat                 ← Script de build manuel (si tu as accès à un PC Windows)
└── README.md                     ← Présentation commerciale du produit
```

## Étapes (10 minutes, une seule fois)

### 1. Crée un compte GitHub
Si tu n'en as pas déjà un : https://github.com/signup (gratuit).

### 2. Crée un nouveau dépôt (repository)
- Va sur https://github.com/new
- Nom du dépôt : `sysdiag` (ou ce que tu veux)
- Visibilité : **Privé** (recommandé, vu que c'est un logiciel commercial — voir note ci-dessous)
- Ne coche aucune case d'initialisation (pas de README, pas de .gitignore)
- Clique sur **Create repository**

### 3. Envoie ce dossier sur GitHub

GitHub te montrera des commandes après la création. Depuis ce dossier (`sysdiag-release`), ouvre un terminal et tape :

```bash
git init
git add .
git commit -m "Version initiale"
git branch -M main
git remote add origin https://github.com/TON-NOM-UTILISATEUR/sysdiag.git
git push -u origin main
```

(Remplace `TON-NOM-UTILISATEUR` par ton pseudo GitHub. Tu devras peut-être créer un "Personal Access Token" si GitHub te le demande à la place d'un mot de passe — GitHub te guidera.)

### 4. Regarde le robot compiler tout seul
- Va dans l'onglet **Actions** de ton dépôt GitHub
- Tu verras un build nommé "Build SysDiag .exe" en cours (icône jaune = en cours, vert = réussi)
- Ça prend 2 à 4 minutes

### 5. Télécharge ton .exe
- Une fois le build vert ✅, clique dessus
- En bas de la page, dans la section **Artifacts**, clique sur `SysDiag_v4-windows`
- Ça télécharge un `.zip` contenant ton `SysDiag_v4.exe`, prêt à distribuer

## Et après ? À chaque modification du code

Dès que tu modifies `SysDiag_v4.py` et que tu refais :
```bash
git add .
git commit -m "Description du changement"
git push
```
... un nouveau `.exe` est recompilé automatiquement. Tu n'as plus jamais besoin de Windows.

## ⚠️ Note importante : dépôt privé vs public

Comme SysDiag est vendu commercialement (licence propriétaire), **mets bien le dépôt en "Privé"** à l'étape 2. Un dépôt public rendrait ton code source visible et téléchargeable par n'importe qui, ce qui contredirait ta licence commerciale.

Le compte GitHub gratuit permet un nombre illimité de dépôts privés et inclut des minutes de build Actions gratuites (généreuses pour ce genre de projet — largement suffisant pour un usage normal).

## Alternative : build manuel sur PC Windows

Si tu préfères ne pas utiliser GitHub, le fichier `build_exe.bat` fait la même chose en local : place tous les fichiers dans un dossier sur un PC Windows et double-clique dessus. Voir `PACKAGING.md` (fourni précédemment) pour le détail des pièges (antivirus, signature numérique, etc.).
